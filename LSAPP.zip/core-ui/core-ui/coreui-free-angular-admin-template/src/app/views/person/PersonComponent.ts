import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Http } from '@angular/http';

@Component({
    templateUrl: '../person/person.html'
})
export class PersonComponent {

    constructor(private modalService: NgbModal,
        private http: Http) { }

    rowData = [
        { make: 'TATA Indica', model: 'Indica' },
        { make: 'TATA Nano', model: 'Nano' },
        { make: 'Hundai i10', model: 'i10' },
        { make: 'TATA Safari', model: 'Safari' },
        { make: 'TATA Sumo', model: 'Sumo' },
        { make: 'Toyota Innova', model: 'Innova' }
    ];
    open(content) {
        this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
            //this.closeResult = `Closed with: ${result}`;
        }, (reason) => {
            //this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        });
    }


}