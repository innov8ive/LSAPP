import { Component, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { Message } from 'primeng/api';
import { Common } from '../gridbase/Common';

@Component({
selector: 'OrgAddress',
templateUrl: '../OrgMaster/OrgAddressComponent.html'
})
export class OrgAddressComponent {
@Input() OrgMaster: any;

EditMode: boolean=false;

OrgAddressSubmitted: boolean = false;

OrgAddress = {};
OrgAddressLocal = [];
editOrgAddress(indx) {
this.EditMode = true;
this.OrgAddress = this.OrgMaster.OrgAddressList[indx];
this.OrgAddressLocal = this.OrgMaster.OrgAddressList.map(x => Object.assign({}, x));
}
deleteOrgAddress(indx) {
if (confirm('Are you sure want to delete?') == true) {
this.OrgMaster.OrgAddressList.splice(indx, 1);
}
}
newOrgAddress() {
this.EditMode = true;
this.OrgAddressSubmitted = false;
this.OrgAddressLocal = this.OrgMaster.OrgAddressList.map(x => Object.assign({}, x));
this.OrgAddress = {};
this.OrgMaster.OrgAddressList.push(this.OrgAddress);
}
cancelOrgAddress() {
this.EditMode = false;
this.OrgAddress = {};
this.OrgMaster.OrgAddressList = this.OrgAddressLocal.map(x => Object.assign({}, x));
}
updateOrgAddress (indx:number, formOrgAddress: NgForm) {
this.OrgAddressSubmitted = true;
if (formOrgAddress.invalid == true) return;
this.EditMode = false;
this.OrgAddress = {};
};
}
