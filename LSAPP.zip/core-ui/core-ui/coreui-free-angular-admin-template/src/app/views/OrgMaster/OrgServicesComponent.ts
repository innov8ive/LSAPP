import { Component, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { Message } from 'primeng/api';
import { Common } from '../gridbase/Common';

@Component({
selector: 'OrgServices',
templateUrl: '../OrgMaster/OrgServicesComponent.html'
})
export class OrgServicesComponent {
@Input() OrgMaster: any;

EditMode: boolean=false;

OrgServicesSubmitted: boolean = false;

OrgServices = {};
OrgServicesLocal = [];
editOrgServices(indx) {
this.EditMode = true;
this.OrgServices = this.OrgMaster.OrgServicesList[indx];
this.OrgServicesLocal = this.OrgMaster.OrgServicesList.map(x => Object.assign({}, x));
}
deleteOrgServices(indx) {
if (confirm('Are you sure want to delete?') == true) {
this.OrgMaster.OrgServicesList.splice(indx, 1);
}
}
newOrgServices() {
this.EditMode = true;
this.OrgServicesSubmitted = false;
this.OrgServicesLocal = this.OrgMaster.OrgServicesList.map(x => Object.assign({}, x));
this.OrgServices = {};
this.OrgMaster.OrgServicesList.push(this.OrgServices);
}
cancelOrgServices() {
this.EditMode = false;
this.OrgServices = {};
this.OrgMaster.OrgServicesList = this.OrgServicesLocal.map(x => Object.assign({}, x));
}
updateOrgServices (indx:number, formOrgServices: NgForm) {
this.OrgServicesSubmitted = true;
if (formOrgServices.invalid == true) return;
this.EditMode = false;
this.OrgServices = {};
};
}
