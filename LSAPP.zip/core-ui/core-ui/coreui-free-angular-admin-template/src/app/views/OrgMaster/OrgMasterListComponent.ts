import { Component, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { TableComponent } from '../gridbase/table';
import { Message } from 'primeng/api';

@Component({
templateUrl: '../OrgMaster/OrgMasterListComponent.html'
})
export class OrgMasterListComponent {
@ViewChild('myTable') myTable: TableComponent;
cols = [

{ field: 'OrgDate', header: 'OrgDate', format:'dd-MMM-yyyy' },
{ field: 'OrgName', header: 'OrgName' },
{ field: 'OrgTurnOver', header: 'OrgTurnOver' },];
dataKey: string = 'OrgID';
searchText: string = '';
msgs: Message[] = [];

constructor(private _router: Router, private http: HttpClient) { }
searchOrgMaster() {
this.myTable.loadData(this.searchText);
}
newOrgMaster() {
this._router.navigate(['/OrgMaster', 0]);
}
editOrgMaster() {

if (this.myTable.selectedRow == null) {
alert('Please select a row to edit');
return;
}
this._router.navigate(['/OrgMaster', this.myTable.selectedRow.OrgID]);
}
deleteOrgMaster() {
if (this.myTable.selectedRow == null) {
alert('Please select a row to edit');
return;
}
this.http.delete('api/OrgMaster/' + this.myTable.selectedRow.OrgID).subscribe(
result => {
this.msgs.push({ severity: 'success', summary: 'Success Message', detail: 'Data Deleted Successfully!' });
this.searchOrgMaster();
},
error => {
this.msgs.push({
severity: 'error', summary: 'Error Message', detail: 'Data not Deleted!\n'
+ error.message
});
}
);
}
}
