import { Component, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { Message } from 'primeng/api';
import { Common } from '../gridbase/Common';
import { OrgAddressComponent } from './OrgAddressComponent';
import { OrgServicesComponent } from './OrgServicesComponent';

@Component({
templateUrl: '../OrgMaster/OrgMasterComponent.html'
})
export class OrgMasterComponent {
OrgID: any;
OrgMaster: any = {};
msgs: Message[] = [];
formOrgMasterSubmitted: boolean = false;
common: Common = new Common();
@ViewChild('OrgAddress') OrgAddress: OrgAddressComponent;
@ViewChild('OrgServices') OrgServices: OrgServicesComponent;

constructor(private route: ActivatedRoute, private router: Router, private http: HttpClient) {
this.OrgID = route.snapshot.params['OrgID'];
this.loadOrgMaster();
}

loadOrgMaster() {
this.http.get('api/OrgMaster/' + this.OrgID).subscribe(result => {
this.OrgMaster = JSON.parse(result as string);
this.common.ParseISODate(this.OrgMaster);
});
}
saveOrgMaster(formOrgMaster: NgForm) {
this.formOrgMasterSubmitted = true;
if (formOrgMaster.invalid == true) return;
if((this.OrgAddress && this.OrgAddress.EditMode==true) || (this.OrgServices && this.OrgServices.EditMode==true)){
this.msgs.push({
severity: 'error', summary: 'Error Message', detail: 'Please update the Current Tab'
});
return;
}
this.common.ToISODate(this.OrgMaster);
this.http.post('api/OrgMaster/', this.OrgMaster).subscribe(
result => {

result = JSON.parse(result as string);
if (result instanceof Array) {
for (var j = 0; j < result.length; j++) {
this.msgs.push({
severity: 'error', summary: 'Error Message', detail: result[j].ErrorMessage
});
}
}
else {
this.msgs.push({ severity: 'success', summary: 'Success Message', detail: 'Data Saved Successfully!' });
this.OrgMaster = result;
this.common.ParseISODate(this.OrgMaster);
}
},
error => {
this.msgs.push({
severity: 'error', summary: 'Error Message', detail: 'Data not Saved Successfully!\n'+ error.error.ExceptionMessage
});
}
);
}
goBack() {
this.router.navigate(['/OrgMasterList']);
}
}
