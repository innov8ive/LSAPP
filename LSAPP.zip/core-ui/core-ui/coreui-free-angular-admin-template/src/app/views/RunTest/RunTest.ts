import { Component } from '@angular/core';

@Component({
    templateUrl: '../RunTest/RunTest.html'
})
export class RunTestComponent {

}