import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { Message } from 'primeng/api';

@Component({
    templateUrl: '../gridbase/FM.html'
})
export class FMComponent {
    FMID: any;
    FM: any = {};
    msgs: Message[] = [];
    formFMSubmitted: boolean = false;

    constructor(private route: ActivatedRoute, private router: Router, private http: HttpClient) {
        this.FMID = route.snapshot.params['FMID'];
        this.loadFM();
    }

    loadFM() {
        this.http.get('api/FM/' + this.FMID).subscribe(result => {
            this.FM = JSON.parse(result as string);
        });
    }
    saveFM(formFM: NgForm) {
        this.formFMSubmitted = true;
        if (formFM.invalid == true) return;
        this.http.post('api/FM/', this.FM).subscribe(
            result => {
                
                result = JSON.parse(result as string);
                if (result instanceof Array) {
                    for (var j = 0; j < result.length; j++) {
                        this.msgs.push({
                            severity: 'error', summary: 'Error Message', detail: result[j].ErrorMessage
                        });
                    }
                }
                else {
                    this.msgs.push({ severity: 'success', summary: 'Success Message', detail: 'Data Saved Successfully!' });
                    this.FM = JSON.parse(result as string);
                }
            },
            error => {
                this.msgs.push({
                    severity: 'error', summary: 'Error Message', detail: 'Data not Saved Successfully!\n'
                        + error.error.ExceptionMessage
                });
            }
        );
    }
    goBack() {
        this.router.navigate(['/FMList']);
    }
}