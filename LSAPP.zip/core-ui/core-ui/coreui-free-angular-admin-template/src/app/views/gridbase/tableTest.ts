import { Component, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { TableComponent } from './table';
import { Message } from 'primeng/api';

@Component({
    templateUrl: '../gridbase/tableTest.html'
})
export class TableTestComponent {
    @ViewChild('myTable') myTable: TableComponent;
    cols = [
        { field: 'FMID', header: 'FMID' },
        { field: 'FMName', header: 'FM Name' },
        { field: 'Rel', header: 'Rel' },
        { field: 'AddedBy', header: 'Added By' }
    ];
    dataKey: string = 'FMID';
    searchText: string = '';
    msgs: Message[] = [];

    constructor(private _router: Router, private http: HttpClient) { }
    searchFM() {
        this.myTable.loadData(this.searchText);
    }
    newFM() {
        this._router.navigate(['/FM', 0]);
    }
    editFM() {
       
        if (this.myTable.selectedRow == null) {
            alert('Please select a row to edit');
            return;
        }
        this._router.navigate(['/FM', this.myTable.selectedRow.FMID]);
    }
    deleteFM() {
        if (this.myTable.selectedRow == null) {
            alert('Please select a row to edit');
            return;
        }
        this.http.delete('api/FM/' + this.myTable.selectedRow.FMID).subscribe(
            result => {
                this.msgs.push({ severity: 'success', summary: 'Success Message', detail: 'Data Deleted Successfully!' });
                this.searchFM();
            },
            error => {
                this.msgs.push({
                    severity: 'error', summary: 'Error Message', detail: 'Data not Deleted!\n'
                        + error.message
                });
            }
        );
    }
}