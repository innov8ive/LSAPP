import { Component, ViewChild, TemplateRef } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { Http } from '@angular/http';

@Component({
    templateUrl: '../Test/Test.html'
})
export class TestComponent {
    @ViewChild("sectionToolBar") sectionToolBar: any;

    rows: any = [];
    sectionList: any = [];
    selectedSection: any = {};
    elementList: any = [];
    objElement: any = {};

    private sectionModalRef: NgbModalRef;
    private elementModalRef: NgbModalRef;
    private currentRowIndex;
    private currentSectionIndex;
    private maxElementId: number = 0;

    constructor(private modalService: NgbModal,
        private http: Http) {

        this.sectionList.push({ text: 'Col4 + Col4 + Col4', value: 'col-4,col-4,col-4' });
        this.sectionList.push({ text: 'Col3 + Col3 + Col3 + Col3', value: 'col-3,col-3,col-3,col-3' });
        this.sectionList.push({ text: 'Col6 + Col6', value: 'col-6,col-6' });
        this.sectionList.push({ text: 'Col2 + Col4 + Col2 + Col4', value: 'col-2,col-4,col-2,col-4' });
        this.sectionList.push({ text: 'Col12', value: 'col-12' });
        this.sectionList.push({ text: 'Col3 + Col9', value: 'col-3,col-9' });
        this.sectionList.push({ text: 'Col9 + Col3', value: 'col-9,col-3' });
        this.sectionList.push({ text: 'Col4 + Col8', value: 'col-4,col-8' });
        this.sectionList.push({ text: 'Col8 + Col4', value: 'col-8,col-4' });
        this.selectedSection = this.sectionList[0].value;

        this.elementList.push({ label: 'Textbox', value: 'Textbox' });
        this.elementList.push({ label: 'Label', value: 'Label' });
        this.elementList.push({ label: 'Text Block', value: 'TextBlock' });
        this.elementList.push({ label: 'Single Select Dropdownlist', value: 'SingleSelectDropdownlist', reqMetadata: true });
        this.elementList.push({ label: 'Single Select Radio', value: 'SingleSelectRadio', reqMetadata: true });
        this.elementList.push({ label: 'Multiple Select', value: 'MultipleSelect', reqMetadata: true });
        this.elementList.push({ label: 'Big Heading', value: 'BigHeading' });
        this.elementList.push({ label: 'Small Heading', value: 'SmallHeading' });
    }


    openSectionPopup(content) {

        this.selectedSection = this.sectionList[0].value;
        this.sectionModalRef = this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', size: 'lg' });
    }
    addSection() {
        if (this.selectedSection != null) {
            var options = this.selectedSection.split(',');
            var sections = [];
            for (var j = 0; j < options.length; j++) {
                sections.push({ col: options[j], elements: [] });
            }
            this.rows.push({ sections: sections });
            this.sectionModalRef.close();
        }
    }
    deleteSection(rowIndex: number) {
        this.rows.splice(rowIndex, 1);
    }


    openElementPopup(content) {
        this.objElement = {};
        this.elementModalRef = this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', size: 'lg' });
    }
    addElement() {
        if (this.objElement.Type != null) {
            if (this.objElement.Id == null) {
                this.maxElementId++;
                this.objElement.Id = this.maxElementId;
                this.rows[this.currentRowIndex].sections[this.currentSectionIndex].elements.push(this.objElement);
            }
            else {

            }
        }
        this.elementModalRef.close();
    }
    mouseEnterSection(objEvent: any) {
        this.currentRowIndex = objEvent.currentTarget.getAttribute('rowIndex');
        this.currentSectionIndex = objEvent.currentTarget.getAttribute('sectionIndex');
        objEvent.currentTarget.appendChild(this.sectionToolBar.nativeElement);
    }
    mouseLeaveSection(objEvent: any) {
        document.body.appendChild(this.sectionToolBar.nativeElement);
        this.sectionToolBar.nativeElement.parentNode.removeChild(this.sectionToolBar.nativeElement);
    }
    editElementPopup(content, element: any) {
        this.objElement = element;
        this.elementModalRef = this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', size: 'lg' });
    }
    deleteElement() {
        var allElementsInSection = this.rows[this.currentRowIndex].sections[this.currentSectionIndex].elements;
        for (var i = 0; i < allElementsInSection.length; i++) {
            if (allElementsInSection[i] == this.objElement) {
                allElementsInSection.splice(i, 1);
                break;
            }
        }
        this.elementModalRef.close();
    }
}