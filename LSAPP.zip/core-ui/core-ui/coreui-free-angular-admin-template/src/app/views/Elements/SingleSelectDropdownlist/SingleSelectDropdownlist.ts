import { Component, Input } from '@angular/core';

@Component({
    templateUrl: '../SingleSelectDropdownlist/SingleSelectDropdownlist.html',
    selector:'dropdownlist'
})
export class SingleSelectDropdownlistComponent {

    @Input() val:string='';
    @Input() type:string='single';
}