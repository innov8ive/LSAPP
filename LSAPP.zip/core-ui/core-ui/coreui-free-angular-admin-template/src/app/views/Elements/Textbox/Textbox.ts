import { Component, Input } from '@angular/core';

@Component({
    templateUrl: '../Textbox/Textbox.html',
    selector: 'textbox'
})
export class TextboxComponent {
    @Input() val: string = '';
}