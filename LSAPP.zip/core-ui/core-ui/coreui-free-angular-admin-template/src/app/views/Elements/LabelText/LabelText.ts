import { Component, Input } from '@angular/core';

@Component({
    templateUrl: '../LabelText/LabelText.html',
    selector:'label-text'
})
export class LabelTextComponent {

    @Input() val:string='';
}