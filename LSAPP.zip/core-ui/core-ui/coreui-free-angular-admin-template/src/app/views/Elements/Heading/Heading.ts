import { Component, Input } from '@angular/core';

@Component({
    templateUrl: '../Heading/Heading.html',
    selector:'heading'
})
export class HeadingComponent {

    @Input() val:string='';
    @Input() type:string='BigHeading';
}