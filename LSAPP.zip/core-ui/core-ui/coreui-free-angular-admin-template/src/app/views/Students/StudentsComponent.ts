import { Component, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { Message } from 'primeng/api';
import { Common } from '../gridbase/Common';
import { StudentBookComponent } from './StudentBookComponent';
import { StudentContactComponent } from './StudentContactComponent';
import { StudentCourseComponent } from './StudentCourseComponent';
import { LoadingIndicatorService } from '../../LoadingIndicatorService';

@Component({
    templateUrl: '../Students/StudentsComponent.html'
})
export class StudentsComponent {
    StudentID: any;
    Students: any = {};
    msgs: Message[] = [];
    formStudentsSubmitted: boolean = false;
    common: Common = new Common();
    loading: boolean = false;
    @ViewChild('StudentBook') StudentBook: StudentBookComponent;
    @ViewChild('StudentContact') StudentContact: StudentContactComponent;
    @ViewChild('StudentCourse') StudentCourse: StudentCourseComponent;

    constructor(private route: ActivatedRoute, private router: Router, private http: HttpClient
        ,private loadingIndicatorService: LoadingIndicatorService
    ) {
        this.StudentID = route.snapshot.params['StudentID'];
        this.loadStudents();

        loadingIndicatorService
        .onLoadingChanged
        .subscribe(isLoading => this.loading = isLoading);
    }

    loadStudents() {
        this.http.get('api/Students/' + this.StudentID).subscribe(result => {
            this.Students = JSON.parse(result as string);
            this.common.ParseISODate(this.Students);
        });
    }
    saveStudents(formStudents: NgForm) {
        this.formStudentsSubmitted = true;
        if (formStudents.invalid == true) return;
        if ((this.StudentBook && this.StudentBook.EditMode == true) || (this.StudentContact && this.StudentContact.EditMode == true) || (this.StudentCourse && this.StudentCourse.EditMode == true)) {
            this.msgs.push({
                severity: 'error', summary: 'Error Message', detail: 'Please update the Current Tab'
            });
            return;
        }
        this.common.ToISODate(this.Students);
        this.http.post('api/Students/', this.Students).subscribe(
            result => {

                result = JSON.parse(result as string);
                if (result instanceof Array) {
                    for (var j = 0; j < result.length; j++) {
                        this.msgs.push({
                            severity: 'error', summary: 'Error Message', detail: result[j].ErrorMessage
                        });
                    }
                }
                else {
                    this.msgs.push({ severity: 'success', summary: 'Success Message', detail: 'Data Saved Successfully!' });
                    this.Students = result;
                    this.common.ParseISODate(this.Students);
                }
            },
            error => {
                this.msgs.push({
                    severity: 'error', summary: 'Error Message', detail: 'Data not Saved Successfully!\n' + error.error.ExceptionMessage
                });
            }
        );
    }
    goBack() {
        this.router.navigate(['/StudentsList']);
    }
}
