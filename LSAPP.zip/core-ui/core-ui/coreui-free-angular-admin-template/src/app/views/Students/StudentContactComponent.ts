import { Component, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { Message } from 'primeng/api';
import { Common } from '../gridbase/Common';

@Component({
selector: 'StudentContact',
templateUrl: '../Students/StudentContactComponent.html'
})
export class StudentContactComponent {
@Input() Students: any;

EditMode: boolean=false;

StudentContactSubmitted: boolean = false;

StudentContact = {};
StudentContactLocal = [];
editStudentContact(indx) {
this.EditMode = true;
this.StudentContact = this.Students.StudentContactList[indx];
this.StudentContactLocal = this.Students.StudentContactList.map(x => Object.assign({}, x));
}
deleteStudentContact(indx) {
if (confirm('Are you sure want to delete?') == true) {
this.Students.StudentContactList.splice(indx, 1);
}
}
newStudentContact() {
this.EditMode = true;
this.StudentContactSubmitted = false;
this.StudentContactLocal = this.Students.StudentContactList.map(x => Object.assign({}, x));
this.StudentContact = {};
this.Students.StudentContactList.push(this.StudentContact);
}
cancelStudentContact() {
this.EditMode = false;
this.StudentContact = {};
this.Students.StudentContactList = this.StudentContactLocal.map(x => Object.assign({}, x));
}
updateStudentContact (indx:number, formStudentContact: NgForm) {
this.StudentContactSubmitted = true;
if (formStudentContact.invalid == true) return;
this.EditMode = false;
this.StudentContact = {};
};
}
