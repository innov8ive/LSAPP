import { Component, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { TableComponent } from '../gridbase/table';
import { Message } from 'primeng/api';

@Component({
templateUrl: '../Students/StudentsListComponent.html'
})
export class StudentsListComponent {
@ViewChild('myTable') myTable: TableComponent;
cols = [

{ field: 'Address', header: 'Address' },
{ field: 'DOB', header: 'DOB', format:'dd-MMM-yyyy' },
{ field: 'Mobile', header: 'Mobile' },
{ field: 'Name', header: 'Name' },];
dataKey: string = 'StudentID';
searchText: string = '';
msgs: Message[] = [];

constructor(private _router: Router, private http: HttpClient) { }
searchStudents() {
this.myTable.loadData(this.searchText);
}
newStudents() {
this._router.navigate(['/Students', 0]);
}
editStudents() {

if (this.myTable.selectedRow == null) {
alert('Please select a row to edit');
return;
}
this._router.navigate(['/Students', this.myTable.selectedRow.StudentID]);
}
deleteStudents() {
if (this.myTable.selectedRow == null) {
alert('Please select a row to edit');
return;
}
this.http.delete('api/Students/' + this.myTable.selectedRow.StudentID).subscribe(
result => {
this.msgs.push({ severity: 'success', summary: 'Success Message', detail: 'Data Deleted Successfully!' });
this.searchStudents();
},
error => {
this.msgs.push({
severity: 'error', summary: 'Error Message', detail: 'Data not Deleted!\n'
+ error.message
});
}
);
}
}
