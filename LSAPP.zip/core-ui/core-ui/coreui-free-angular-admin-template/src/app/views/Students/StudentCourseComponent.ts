import { Component, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { Message } from 'primeng/api';
import { Common } from '../gridbase/Common';

@Component({
selector: 'StudentCourse',
templateUrl: '../Students/StudentCourseComponent.html'
})
export class StudentCourseComponent {
@Input() Students: any;

EditMode: boolean=false;

StudentCourseSubmitted: boolean = false;

StudentCourse = {};
StudentCourseLocal = [];
editStudentCourse(indx) {
this.EditMode = true;
this.StudentCourse = this.Students.StudentCourseList[indx];
this.StudentCourseLocal = this.Students.StudentCourseList.map(x => Object.assign({}, x));
}
deleteStudentCourse(indx) {
if (confirm('Are you sure want to delete?') == true) {
this.Students.StudentCourseList.splice(indx, 1);
}
}
newStudentCourse() {
this.EditMode = true;
this.StudentCourseSubmitted = false;
this.StudentCourseLocal = this.Students.StudentCourseList.map(x => Object.assign({}, x));
this.StudentCourse = {};
this.Students.StudentCourseList.push(this.StudentCourse);
}
cancelStudentCourse() {
this.EditMode = false;
this.StudentCourse = {};
this.Students.StudentCourseList = this.StudentCourseLocal.map(x => Object.assign({}, x));
}
updateStudentCourse (indx:number, formStudentCourse: NgForm) {
this.StudentCourseSubmitted = true;
if (formStudentCourse.invalid == true) return;
this.EditMode = false;
this.StudentCourse = {};
};
}
