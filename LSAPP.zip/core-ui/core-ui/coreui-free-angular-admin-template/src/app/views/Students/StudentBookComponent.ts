import { Component, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { Message } from 'primeng/api';
import { Common } from '../gridbase/Common';

@Component({
selector: 'StudentBook',
templateUrl: '../Students/StudentBookComponent.html'
})
export class StudentBookComponent {
@Input() Students: any;

EditMode: boolean=false;

StudentBookSubmitted: boolean = false;

StudentBook = {};
StudentBookLocal = [];
editStudentBook(indx) {
this.EditMode = true;
this.StudentBook = this.Students.StudentBookList[indx];
this.StudentBookLocal = this.Students.StudentBookList.map(x => Object.assign({}, x));
}
deleteStudentBook(indx) {
if (confirm('Are you sure want to delete?') == true) {
this.Students.StudentBookList.splice(indx, 1);
}
}
newStudentBook() {
this.EditMode = true;
this.StudentBookSubmitted = false;
this.StudentBookLocal = this.Students.StudentBookList.map(x => Object.assign({}, x));
this.StudentBook = {};
this.Students.StudentBookList.push(this.StudentBook);
}
cancelStudentBook() {
this.EditMode = false;
this.StudentBook = {};
this.Students.StudentBookList = this.StudentBookLocal.map(x => Object.assign({}, x));
}
updateStudentBook (indx:number, formStudentBook: NgForm) {
this.StudentBookSubmitted = true;
if (formStudentBook.invalid == true) return;
this.EditMode = false;
this.StudentBook = {};
};
}
