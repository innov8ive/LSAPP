import { Component, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { Message } from 'primeng/api';
import { Common } from '../gridbase/Common';
import { PLOptionComponent } from './PLOptionComponent';

@Component({
    templateUrl: '../PL/PLComponent.html'
})
export class PLComponent {
    PLID: any;
    PL: any = {};
    msgs: Message[] = [];
    formPLSubmitted: boolean = false;
    common: Common = new Common();
    @ViewChild('PLOption') PLOption: PLOptionComponent;

    constructor(private route: ActivatedRoute, private router: Router, private http: HttpClient) {
        this.PLID = route.snapshot.params['PLID'];
        this.loadPL();
    }

    loadPL() {
        this.http.get('api/PL/' + this.PLID).subscribe(result => {
            this.PL = JSON.parse(result as string);
            this.common.ParseISODate(this.PL);
        });
    }
    savePL(formPL: NgForm) {
        this.formPLSubmitted = true;
        if (formPL.invalid == true) return;
        if (this.PLOption.EditMode == true) {
            this.msgs.push({
                severity: 'error', summary: 'Error Message', detail: 'Please update the Current Tab'
            });
            return;
        }
        this.common.ToISODate(this.PL);
        this.http.post('api/PL/', this.PL).subscribe(
            result => {

                result = JSON.parse(result as string);
                if (result instanceof Array) {
                    for (var j = 0; j < result.length; j++) {
                        this.msgs.push({
                            severity: 'error', summary: 'Error Message', detail: result[j].ErrorMessage
                        });
                    }
                }
                else {
                    this.msgs.push({ severity: 'success', summary: 'Success Message', detail: 'Data Saved Successfully!' });
                    this.PL = result;
                    this.common.ParseISODate(this.PL);
                }
            },
            error => {
                this.msgs.push({
                    severity: 'error', summary: 'Error Message', detail: 'Data not Saved Successfully!\n' + error.error.ExceptionMessage
                });
            }
        );
    }
    goBack() {
        this.router.navigate(['/PLList']);
    }
}
