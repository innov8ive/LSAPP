import { Component, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { TableComponent } from '../gridbase/table';
import { Message } from 'primeng/api';

@Component({
templateUrl: '../PL/PLListComponent.html'
})
export class PLListComponent {
@ViewChild('myTable') myTable: TableComponent;
cols = [

{ field: 'IsActive', header: 'IsActive' },
{ field: 'MultiOptions', header: 'MultiOptions' },
{ field: 'PLDate', header: 'PLDate', format:'dd-MMM-yyyy' },
{ field: 'PLDetails', header: 'PLDetails' },
{ field: 'PLTitle', header: 'PLTitle' },
{ field: 'ShowTill', header: 'ShowTill', format:'dd-MMM-yyyy' },
{ field: 'SocID', header: 'SocID' },];
dataKey: string = 'PLID';
searchText: string = '';
msgs: Message[] = [];

constructor(private _router: Router, private http: HttpClient) { }
searchPL() {
this.myTable.loadData(this.searchText);
}
newPL() {
this._router.navigate(['/PL', 0]);
}
editPL() {

if (this.myTable.selectedRow == null) {
alert('Please select a row to edit');
return;
}
this._router.navigate(['/PL', this.myTable.selectedRow.PLID]);
}
deletePL() {
if (this.myTable.selectedRow == null) {
alert('Please select a row to edit');
return;
}
this.http.delete('api/PL/' + this.myTable.selectedRow.PLID).subscribe(
result => {
this.msgs.push({ severity: 'success', summary: 'Success Message', detail: 'Data Deleted Successfully!' });
this.searchPL();
},
error => {
this.msgs.push({
severity: 'error', summary: 'Error Message', detail: 'Data not Deleted!\n'
+ error.message
});
}
);
}
}
