import { Component, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { Message } from 'primeng/api';
import { Common } from '../gridbase/Common';

@Component({
selector: 'PLOption',
templateUrl: '../PL/PLOptionComponent.html'
})
export class PLOptionComponent {
@Input() PL: any;

EditMode: boolean=false;

PLOptionSubmitted: boolean = false;

PLOption = {};
PLOptionLocal = [];
editPLOption(indx) {
this.EditMode = true;
this.PLOption = this.PL.PLOptionList[indx];
this.PLOptionLocal = this.PL.PLOptionList.map(x => Object.assign({}, x));
}
deletePLOption(indx) {
if (confirm('Are you sure want to delete?') == true) {
this.PL.PLOptionList.splice(indx, 1);
}
}
newPLOption() {
this.EditMode = true;
this.PLOptionSubmitted = false;
this.PLOptionLocal = this.PL.PLOptionList.map(x => Object.assign({}, x));
this.PLOption = {};
this.PL.PLOptionList.push(this.PLOption);
}
cancelPLOption() {
this.EditMode = false;
this.PLOption = {};
this.PL.PLOptionList = this.PLOptionLocal.map(x => Object.assign({}, x));
}
updatePLOption (indx:number, formPLOption: NgForm) {
this.PLOptionSubmitted = true;
if (formPLOption.invalid == true) return;
this.EditMode = false;
this.PLOption = {};
};
}
