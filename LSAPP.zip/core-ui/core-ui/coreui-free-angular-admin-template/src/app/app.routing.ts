import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Import Containers
import { DefaultLayoutComponent } from './containers';

import { LoginComponent } from './views/login/login.component';
import { RegisterComponent } from './views/register/register.component';
import { PersonComponent } from './views/person/PersonComponent';
import { TableComponent } from './views/gridbase/table';
import { TableTestComponent } from './views/gridbase/tableTest';
import { FMComponent } from './views/gridbase/FMComponent';
import { PLListComponent } from './views/PL/PLListComponent';
import { PLComponent } from './views/PL/PLComponent';
import { OrgMasterListComponent } from './views/OrgMaster/OrgMasterListComponent';
import { OrgMasterComponent } from './views/OrgMaster/OrgMasterComponent';
import { StudentsListComponent } from './views/Students/StudentsListComponent';
import { StudentsComponent } from './views/Students/StudentsComponent';
import { TestComponent } from './views/Test/Test';


export const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent,
    data: {
      title: 'Login Page'
    }
  },
  {
    path: 'register',
    component: RegisterComponent,
    data: {
      title: 'Register Page'
    }
  },
  {
    path: '',
    component: DefaultLayoutComponent,
    data: {
      title: 'Home'
    },
    children: [
      {
        path: 'test',
        component: TestComponent,
        data: {
          title: 'Test Page'
        }
      },
      {
        path: 'person',
        component: PersonComponent,
        data: {
          title: 'Person Page'
        }
      },
      {
        path: 'FMList',
        component: TableTestComponent,
        data: {
          title: 'Family Member List'
        }
      },
      {
        path: 'FM/:FMID',
        component: FMComponent,
        data: {
          title: 'Family Member'
        }
      },
      {
        path: 'PLList',
        component: PLListComponent,
        data: {
          title: 'PL List'
        }
      },
      {
        path: 'PL/:PLID',
        component: PLComponent,
        data: {
          title: 'PL'
        }
      },
      {
        path: 'OrgMasterList',
        component: OrgMasterListComponent,
        data: {
          title: 'OrgMaster List'
        }
      },
      {
        path: 'OrgMaster/:OrgID',
        component: OrgMasterComponent,
        data: {
          title: 'OrgMaster'
        }
      },
      {
        path: 'StudentsList',
        component: StudentsListComponent,
        data: {
          title: 'Students List'
        }
      },
      {
        path: 'Students/:StudentID',
        component: StudentsComponent,
        data: {
          title: 'Students'
        }
      }

    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
