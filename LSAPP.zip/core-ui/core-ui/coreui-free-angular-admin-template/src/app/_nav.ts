
export const navItems = [
  {
    name: 'Test',
    url: '/test',
    icon: 'icon-speedometer',
    badge: {
      variant: 'info',
      text: 'NEW'
    }
  },
  // {
  //   name: 'Family Member List',
  //   url: '/FMList',
  //   icon: 'fa fa-table'
  // },
  // {
  //   name: 'Poll List',
  //   url: '/PLList',
  //   icon: 'fa fa-table'
  // },
  // {
  //   name: 'OrgMaster List',
  //   url: '/OrgMasterList',
  //   icon: 'fa fa-table'
  // },
  // {
  //   name: 'Students List',
  //   url: '/StudentsList',
  //   icon: 'fa fa-table'
  // },
  // {
  //   title: true,
  //   name: 'Components'
  // },
  // {
  //   name: 'Base',
  //   url: '/base',
  //   icon: 'icon-puzzle',
  //   children: [
  //     {
  //       name: 'Cards',
  //       url: '/base/cards',
  //       icon: 'icon-puzzle'
  //     },
  //     {
  //       name: 'Carousels',
  //       url: '/base/carousels',
  //       icon: 'icon-puzzle'
  //     }
  //   ]
  // },

  // {
  //   name: 'Charts',
  //   url: '/charts',
  //   icon: 'icon-pie-chart'
  // }
];
