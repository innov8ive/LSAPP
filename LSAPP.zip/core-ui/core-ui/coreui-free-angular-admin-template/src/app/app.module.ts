import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, Injectable, EventEmitter } from '@angular/core';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/finally';

import { TableModule } from 'primeng/table';
import { PaginatorModule } from 'primeng/paginator';
import { GrowlModule } from 'primeng/growl';
import { CalendarModule } from 'primeng/calendar';

import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};

import { AppComponent } from './app.component';

// Import containers
import { DefaultLayoutComponent } from './containers';

import { LoginComponent } from './views/login/login.component';
import { RegisterComponent } from './views/register/register.component';

const APP_CONTAINERS = [
  DefaultLayoutComponent
];


@Injectable()
export class APIInterceptor implements HttpInterceptor {
  constructor(private loadingIndicatorService: LoadingIndicatorService) {}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    this.loadingIndicatorService.onStarted(req);

    const apiReq = req.clone({ url: `http://localhost:8080/RM/${req.url}` });
    //const apiReq = req.clone({ url: `http://localhost:11840/${req.url}` });
    return next.handle(apiReq)
    .finally(() => this.loadingIndicatorService.onFinished(req));;
  }
  
}

import {
  AppAsideModule,
  AppBreadcrumbModule,
  AppHeaderModule,
  AppFooterModule,
  AppSidebarModule,
} from '@coreui/angular'

// Import routing module
import { AppRoutingModule } from './app.routing';

// Import 3rd party components
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { ChartsModule } from 'ng2-charts/ng2-charts';
import { PersonComponent } from './views/person/PersonComponent';
import { TableComponent } from './views/gridbase/table';
import { TableTestComponent } from './views/gridbase/tableTest';
import { FMComponent } from './views/gridbase/FMComponent';
import { PLComponent } from './views/PL/PLComponent';
import { PLListComponent } from './views/PL/PLListComponent';
import { PLOptionComponent } from './views/PL/PLOptionComponent';
import { OrgMasterComponent } from './views/OrgMaster/OrgMasterComponent';
import { OrgMasterListComponent } from './views/OrgMaster/OrgMasterListComponent';
import { OrgAddressComponent } from './views/OrgMaster/OrgAddressComponent';
import { OrgServicesComponent } from './views/OrgMaster/OrgServicesComponent';
import { StudentContactComponent } from './views/Students/StudentContactComponent';
import { StudentBookComponent } from './views/Students/StudentBookComponent';
import { StudentCourseComponent } from './views/Students/StudentCourseComponent';
import { StudentsComponent } from './views/Students/StudentsComponent';
import { StudentsListComponent } from './views/Students/StudentsListComponent';
import { LoadingIndicatorService } from './LoadingIndicatorService';
import { TestComponent } from './views/Test/Test';
import { TextboxComponent } from './views/Elements/Textbox/Textbox';
import { LabelTextComponent } from './views/Elements/LabelText/LabelText';
import { HeadingComponent } from './views/Elements/Heading/Heading';
import { SingleSelectDropdownlistComponent } from './views/Elements/SingleSelectDropdownlist/SingleSelectDropdownlist';

@NgModule({
  imports: [
    BrowserAnimationsModule,
    BrowserModule,
    AppRoutingModule,
    AppAsideModule,
    AppBreadcrumbModule.forRoot(),
    AppFooterModule,
    AppHeaderModule,
    AppSidebarModule,
    PerfectScrollbarModule,
    BsDropdownModule.forRoot(),
    TabsModule.forRoot(),
    ChartsModule,
    NgbModule.forRoot(),
    NgSelectModule,
    FormsModule,
    HttpModule,
    HttpClientModule,

    TableModule,
    PaginatorModule,
    GrowlModule,
    CalendarModule
  ],
  declarations: [
    AppComponent,
    ...APP_CONTAINERS,
    LoginComponent,
    RegisterComponent,
    PersonComponent,
    TableComponent,
    TableTestComponent,
    FMComponent,
    PLComponent,
    PLListComponent,
    PLOptionComponent,
    OrgMasterComponent,
    OrgMasterListComponent,
    OrgAddressComponent,
    OrgServicesComponent,
    StudentsComponent,
    StudentsListComponent,
    StudentBookComponent,
    StudentCourseComponent,
    StudentContactComponent,
    TestComponent,

    TextboxComponent,
    LabelTextComponent,
    HeadingComponent,
    SingleSelectDropdownlistComponent
  ],
  providers: [{
    provide: LocationStrategy,
    useClass: HashLocationStrategy
  }, LoadingIndicatorService,{
    provide: HTTP_INTERCEPTORS,
    useFactory: (service: LoadingIndicatorService) => new APIInterceptor(service),
    multi: true, 
    deps: [LoadingIndicatorService]
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
