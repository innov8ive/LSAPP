import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { CustomerPage } from './Customer';

@Component({
    selector: 'customer-list',
    templateUrl: 'CustomerList.html'
})
export class CustomerListPage {
    selectedItem: any;
    items: any[];
    showSearch: boolean = false;
    myInput: string = '';
    constructor(public navCtrl: NavController, public navParams: NavParams,
        public storage: Storage) {

    }

    itemTapped(event, item, indx) {
        this.selectedItem = item;
        // That's right, we're pushing to ourselves!
        this.navCtrl.push(CustomerPage, {
            title: item.Name,
            index: indx,
            parentPage: this
        });
    }
    AddNew() {
        this.navCtrl.push(CustomerPage, {
            title: 'New Customer',
            index: -1,
            parentPage: this
        });
    }
    onInput() {
        this.search(null);
    }
    search(refresher) {
        this.storage.get('cust').then((val) => {
            if (val == null) {
                this.items = [];
                this.items.push({ icon: 'contact', Name: 'Sanjay Gupta', Address: 'Mumbai', Note: '' });
                this.items.push({ icon: 'contact', Name: 'Awadhendra Tripathi', Address: 'New Delhi', Note: '' });
                this.items.push({ icon: 'contact', Name: 'Swapnil Bhoir', Address: 'Chennai', Note: '' });
                this.items.push({ icon: 'contact', Name: 'Ayaz Sheikh', Address: 'Mira Road', Note: '' });
                this.items.push({ icon: 'contact', Name: 'Adeel Sheikh', Address: 'Mumbai', Note: '' });
                this.items.push({ icon: 'contact', Name: 'Zaheer Khan', Address: 'Mumbai', Note: '' });
                this.items.push({ icon: 'contact', Name: 'Mahendra Singh', Address: 'Ranchi', Note: '' });
                this.storage.set('cust', JSON.stringify(this.items));
            }
            else {
                this.items = JSON.parse(val) as any[];
            }
            if (refresher != null)
                refresher.complete();
        });
    }
    ionViewWillEnter() {
        this.search(null);
    }
    searchClicked() {
        this.myInput = '';
        this.showSearch = !this.showSearch;
    }
}
