import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

import { Storage } from '@ionic/storage';


@Component({
    selector: 'customer',
    templateUrl: 'Customer.html'
})
export class CustomerPage {
    title: string = '';
    objCustomer: any = {};
    index = -1;
    custList: any;
    ports: any;
    constructor(public navCtrl: NavController, public navParams: NavParams,
        public storage: Storage) {
        this.ports = [];
        this.ports.push({ id: '1', name: 'Mumbai' });
        this.ports.push({ id: '2', name: 'Delhi' });
        this.ports.push({ id: '3', name: 'Chennai' });
        this.ports.push({ id: '4', name: 'Kolkata' });
        this.title = navParams.get('title');
        this.index = navParams.get('index');
        this.storage.get('cust').then((val) => {
            if (val != null) {
                this.custList = JSON.parse(val);
                if (this.index >= 0) {
                    this.objCustomer = this.custList[this.index]
                }
                else {
                    this.objCustomer = { Name: '', Address: '', Note: '', icon: 'contact' };
                }
            }
        });

    }

    goBack() {
        this.navCtrl.pop();
    }
    update() {
        if (this.index == -1) {
            this.custList.push(this.objCustomer);
        }
        else {
            this.custList[this.index] = this.objCustomer;
        }
        this.storage.set('cust', JSON.stringify(this.custList));
        this.navCtrl.pop();
    }
}