import { Component } from '@angular/core';
import { NavController, NavParams, AlertController } from 'ionic-angular';
import { LoadingController } from 'ionic-angular';
import { HttpClient } from '@angular/common/http';
import { GlobalProvider } from '../../Global';


@Component({
    selector: 'fm',
    templateUrl: 'FM.html'
})
export class FMPage {
    title: string = '';
    objFM: any = {};
    FMID = -1;
    custList: any;
    ports: any = [];
    loader: any;

    constructor(public navCtrl: NavController, public navParams: NavParams,
        public http: HttpClient, public loadingCtrl: LoadingController,
        public global: GlobalProvider, public alertCtrl: AlertController) {
        this.FMID = navParams.get('FMID');
        this.loadData();

        this.ports = [];
        this.ports.push({ id: '1', name: 'Mumbai' });
        this.ports.push({ id: '2', name: 'Delhi' });
        this.ports.push({ id: '3', name: 'Chennai' });
        this.ports.push({ id: '4', name: 'Kolkata' });
    }
    portChange(event) {
        //let text = event.text.trim().toLowerCase();
        event.component.startSearch();
        this.ports = [];

        for (var j = 1; j <= 20; j++) {
            this.ports.push({ id: j.toString(), name: event.text + j.toString() });
        }

        window.setTimeout(()=>{
            event.component.endSearch();
            event.component.enableInfiniteScroll();
        },100);
       


    }
    loadData() {
        this.loader = this.loadingCtrl.create({ content: "Loading..." });
        this.loader.present();
        this.http.get(this.global.ApiUrl + 'api/FM/' + this.FMID, {})
            .subscribe(data => {
                this.objFM = JSON.parse(data as string);
                this.loader.dismiss();
            });
    }
    goBack() {
        this.navCtrl.pop();
    }
    update() {
        this.loader = this.loadingCtrl.create({ content: "Saving..." });
        this.loader.present();
        this.http.post(this.global.ApiUrl + 'api/FM', this.objFM, {})
            .subscribe(data => {
                this.loader.dismiss();
                this.objFM = JSON.parse(data as string);
                this.showAlert('Data Saved Successfully!');
            });
    }
    showAlert(message: string) {
        const alert = this.alertCtrl.create({
            title: 'My TestApp!',
            subTitle: message,
            buttons: ['OK']
        });
        alert.present();
    }
}