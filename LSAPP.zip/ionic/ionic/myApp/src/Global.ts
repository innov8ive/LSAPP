import { Injectable } from '@angular/core';

@Injectable()
export class GlobalProvider {
    public ApiUrl: string = 'http://localhost:8080/RM/';
}