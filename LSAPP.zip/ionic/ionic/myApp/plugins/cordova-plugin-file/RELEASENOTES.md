### 6.0.1 (Dec 27, 2017)
* [CB-13704](https://issues.apache.org/jira/browse/CB-13704) Fix to allow 6.0.0 version install

