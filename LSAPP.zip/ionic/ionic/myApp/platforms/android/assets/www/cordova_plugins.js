cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "id": "cordova-plugin-advanced-http.lodash",
        "file": "plugins/cordova-plugin-advanced-http/www/lodash.js",
        "pluginId": "cordova-plugin-advanced-http"
    },
    {
        "id": "cordova-plugin-advanced-http.tough-cookie",
        "file": "plugins/cordova-plugin-advanced-http/www/umd-tough-cookie.js",
        "pluginId": "cordova-plugin-advanced-http"
    },
    {
        "id": "cordova-plugin-advanced-http.messages",
        "file": "plugins/cordova-plugin-advanced-http/www/messages.js",
        "pluginId": "cordova-plugin-advanced-http"
    },
    {
        "id": "cordova-plugin-advanced-http.local-storage-store",
        "file": "plugins/cordova-plugin-advanced-http/www/local-storage-store.js",
        "pluginId": "cordova-plugin-advanced-http"
    },
    {
        "id": "cordova-plugin-advanced-http.cookie-handler",
        "file": "plugins/cordova-plugin-advanced-http/www/cookie-handler.js",
        "pluginId": "cordova-plugin-advanced-http"
    },
    {
        "id": "cordova-plugin-advanced-http.angular-integration",
        "file": "plugins/cordova-plugin-advanced-http/www/angular-integration.js",
        "pluginId": "cordova-plugin-advanced-http"
    },
    {
        "id": "cordova-plugin-advanced-http.helpers",
        "file": "plugins/cordova-plugin-advanced-http/www/helpers.js",
        "pluginId": "cordova-plugin-advanced-http"
    },
    {
        "id": "cordova-plugin-advanced-http.http",
        "file": "plugins/cordova-plugin-advanced-http/www/advanced-http.js",
        "pluginId": "cordova-plugin-advanced-http",
        "clobbers": [
            "cordova.plugin.http"
        ]
    },
    {
        "id": "cordova-plugin-device.device",
        "file": "plugins/cordova-plugin-device/www/device.js",
        "pluginId": "cordova-plugin-device",
        "clobbers": [
            "device"
        ]
    },
    {
        "id": "cordova-plugin-ionic-keyboard.keyboard",
        "file": "plugins/cordova-plugin-ionic-keyboard/www/android/keyboard.js",
        "pluginId": "cordova-plugin-ionic-keyboard",
        "clobbers": [
            "window.Keyboard"
        ]
    },
    {
        "id": "cordova-plugin-splashscreen.SplashScreen",
        "file": "plugins/cordova-plugin-splashscreen/www/splashscreen.js",
        "pluginId": "cordova-plugin-splashscreen",
        "clobbers": [
            "navigator.splashscreen"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-advanced-http": "1.11.1",
    "cordova-plugin-device": "2.0.2",
    "cordova-plugin-ionic-keyboard": "2.0.5",
    "cordova-plugin-splashscreen": "5.0.2",
    "cordova-plugin-whitelist": "1.3.3"
};
// BOTTOM OF METADATA
});